<?php include_once "header.php"; ?>

    <body>
        <?php include_once "body.php" ?>
        <?php include_once "footer.php" ?>
            
    </body>
</html>
